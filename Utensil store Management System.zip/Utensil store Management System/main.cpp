//Utensil store Management System
#include <iostream>
#include <limits>
#include <fstream>
#include <string>
#include <cstring>
#include <iomanip>
#include <stdio.h>
using namespace std;

struct user
{
    char name[20];
    char address[25];
    char contact[10];
    char passwd[15];
};

struct utensil
{
    char ut_id[5];
    char ut_dis[3];
    char ut_care[6];
    char ut_type[7];
    char ut_name[20];
    char ut_exch[4];
};

class custormer
{
private:
    struct user detail;
public:
    void user_signup();
    void add_user_signup();
    void search_name();
    char *getname(){ return detail.name; }
    void showdata();
};

class admin
{
public:
    struct utensil ut_data;
    void utensil_add();
    void add_utensil_add();
};

int sel,maxm,minm,any,a=0,id,minD,minM,minY,maxD,maxM,maxY,ut_id,ut_price,ut_dis,no;
string passwd,name,ut_name,ut_type,ut_care,ut_exch;
void intro(){
   	cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
    cout<<"::\t\t\t\t\t\t\t::"<<endl;
    cout<<"::\t\t@@@@@@@@@@@@@@@@@@@@@@@\t\t\t::"<<endl;
    cout<<"::\t\t@                     @\t\t\t::"<<endl;
    cout<<"::\t\t@      WELCOME TO     @\t\t\t::"<<endl;
    cout<<"::\t\t@                     @\t\t\t::"<<endl;
    cout<<"::\t\t@    Utensil store    @\t\t\t::"<<endl;
    cout<<"::\t\t@                     @\t\t\t::"<<endl;
    cout<<"::\t\t@  Management System  @\t\t\t::"<<endl;
    cout<<"::\t\t@                     @\t\t\t::"<<endl;
    cout<<"::\t\t@@@@@@@@@@@@@@@@@@@@@@@\t\t\t::"<<endl;
    cout<<"::\t\t\t\t\t\t\t::"<<endl;
    cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
    cout<<endl;
}

void wel_page(){
    cout<<"\t\t\tLOGIN"<<endl;
    cout<<"\t\t1. User"<<endl;
    cout<<"\t\t2. Admin"<<endl;
    cout<<"\t\t3. Exit"<<endl;
    cout<<"\t\tUSMS@non~ $ ";
    cin>>sel;
}

void user_login(){
    cout<<"\t\t\tLOGIN"<<endl;
    cout<<"\t\t1. New User"<<endl;
    cout<<"\t\t2. Old User"<<endl;
    cout<<"\t\t3. Exit"<<endl;
    cout<<"\t\tUSMS@non~ $ ";
    cin>>sel;
}

void custormer :: user_signup(){
    cout<<"\t\t\tSIGN UP"<<endl;
    cout<<"\t\t1. Name"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>detail.name;
    cout<<"\t\t2. Address"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>detail.address;
    cout<<"\t\t3. Contact No."<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>detail.contact;
    cout<<"\t\t4. Password"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>detail.passwd;
    cout<<endl;
    cout<<"\t\tUser Account is Successfully Created!!!"<<endl;
    cin.ignore();
    cout <<"\t\tPress Enter to Continue";
    cin.get();
}

void custormer :: add_user_signup(){
    custormer obj;
    fstream file;
    file.open("custormer_detial.txt", ios::in | ios::out | ios::app);
    obj.user_signup();
    file.write((char *)&obj, sizeof(obj));
    file.close();
}

void user_final_login(){
    cout<<"\t\t\tLOGIN"<<endl;
    cout<<"\t\t1. Name"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    //cin>>detail.name;
    cout<<"\t\t2. Password"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    //cin>>detail.passwd;
    cin.ignore();
    cout <<"\t\tPress Enter to submit";
    cin.get();
}

void custormer :: search_name(){
    custormer obj;
    cout<<"\n\nEnter Name : ";
    cin>>detail.name;
    fstream file;
    file.seekg("custormer_detial.txt",ios::beg);
    int found=0;
    while(file.read((char *) &obj, sizeof(obj)))
    {
        if(strcmp(detail.name,obj.getname())==0)
        {
            found=1;
            obj.showdata();
        }
    }
    file.clear();
    file.close();
    if(found==0)
        cout<<"\n\n---Record Not found---\n";
}

void custormer :: showdata(){
    cout<<"\n";
    cout<<setw(20)<<detail.name;
    cout<<setw(15)<<detail.passwd;
}

void utensil_type(){
    cout<<"\t\t\tUTENSIL TYPES"<<endl;
    cout<<"\t\t1. Copper"<<endl;
    cout<<"\t\t2. Steel"<<endl;
    cout<<"\t\t3. Silver"<<endl;
    cout<<"\t\t4. Exit"<<endl;
    cout<<"\t\tUSMS@non~ $ ";
    cin>>sel;
}

void utensil_list(){
    cout<<"\t\t\tUTENSIL LIST"<<endl;
    cout<<"\t\t1. List all the utensil"<<endl;
    cout<<"\t\t2. By applying filters"<<endl;
    cout<<"\t\t3. Exit"<<endl;
    cout<<"\t\tUSMS@non~ $ ";
    cin>>sel;
}

void utensil_final_list(){
    cout<<"\t\t\tLIST OF UTENSILS"<<endl;

    //cin.ignore();
    cout <<"\t\tPress Enter to submit";
    cin.get();;

}

void utensil_filter(){
    cout<<"\t\t\tUTENSIL LIST"<<endl;
    //price
    cout<<"\t\t1. Price"<<endl;
    cout<<"\t\ti. min and max"<<endl;
    cout<<"\t\tii. any"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>sel;
    switch(sel){
    case 1:
        cout<<"\t\tUSMS@user~ $ ";
        cin>>minm>>maxm;
    case 2:
        //exit command
        ;
    }
    //dicount
    cout<<"\t\t2. Discount"<<endl;
    cout<<"\t\ti. min and max"<<endl;
    cout<<"\t\tii. any"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>sel;
    switch(sel){
    case 1:
        cout<<"\t\tUSMS@user~ $ ";
        cin>>minm>>maxm;
    case 2:
        //exit command
        ;
    }
    //Soap
    cout<<"\t\t3. Based on washing"<<endl;
    cout<<"\t\ti. water only"<<endl;
    cout<<"\t\tii. soap only"<<endl;
    cout<<"\t\tiii. any(0)"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>sel;
    switch(sel){
    case 1:
        //water
        ;
    case 2:
        //soap only
        ;
    case 3:
        //exit command
        ;
    }
    //exchange
    cout<<"\t\t4. Exchangeable"<<endl;
    cout<<"\t\ti. yes exchangeable "<<endl;
    cout<<"\t\tii. not exchangeable"<<endl;
    cout<<"\t\tiii. any(0)"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>sel;
    switch(sel){
    case 1:
        //water
        ;
    case 2:
        //soap only
        ;
    case 3:
        //exit command
        ;
    }
}

void utensil_data(){
    cout<<"\t\t\tUTENSIL DATA"<<endl;
    //URENSIL DATA
    cout<<"\t\t1. Buy"<<endl;
    cout<<"\t\t2. exit"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>sel;
}

void bill(){
    cout<<"\t\t\tYOUR BILL"<<endl;
    //URENSIL DATA
    cout<<"\t\tConfirm to buy"<<endl;
    cout<<"\t\t1. yes"<<endl;
    cout<<"\t\t2. no"<<endl;
    cout<<"\t\tUSMS@user~ $ ";
    cin>>sel;
}

void cong(){
    cout<<endl<<endl;
    cout<<"\t\t\tCONGRATULATION!!!"<<endl;
}

void admin_login(){
    cout<<"\t\t\tLOGIN"<<endl;
    cout<<"\t\t1. User ID"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>id;
    cout<<"\t\t2. Password"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>passwd;
    cin.ignore();
    cout <<"\t\tPress Enter to submit";
    cin.get();
}

void admin_page(){
    cout<<"\t\t\tAdministrator Page"<<endl;
    cout<<"\t\t1. utensil details"<<endl;
    cout<<"\t\t2. user details"<<endl;
    cout<<"\t\t3. Exit"<<endl;
    cout<<"\t\tUSMS@non~ # ";
    cin>>sel;
}

void user_detail(){
    cout<<"\t\t\tUSER DETAIL"<<endl;
    //USER  NAME
    cout<<"\t\t1. Name"<<endl;
    cout<<"\t\ti. by apply name"<<endl;
    cout<<"\t\tii. any"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>sel;
    switch(sel){
    case 1:
        cout<<"\t\tUSMS@user~ # ";
        cin>>name;
    case 2:
        //exit command
        ;
    }

    //DATE
    cout<<"\t\t2. DATE"<<endl;
    cout<<"\t\ti. min and max(DD MM YYYY)"<<endl;
    cout<<"\t\tii. any"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>sel;
    switch(sel){
    case 1:
        cout<<"\t\tUSMS@user~ # ";
        cin>>minD>>minM>>minY>>maxD>>maxM>>maxY;
    case 2:
        //exit command
        ;
    }


    //price
    cout<<"\t\t3. Price"<<endl;
    cout<<"\t\ti. min and max"<<endl;
    cout<<"\t\tii. any"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>sel;
    switch(sel){
    case 1:
        cout<<"\t\tUSMS@user~ # ";
        cin>>minm>>maxm;
    case 2:
        //exit command
        ;
    }

    //no of utesil
    cout<<"\t\t4. No. of utensil byed"<<endl;
    cout<<"\t\ti. by applying no. of utesil"<<endl;
    cout<<"\t\tii. any"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>sel;
    switch(sel){
    case 1:
        cout<<"\t\tUSMS@user~ # ";
        cin>>no;
    case 2:
        //exit command
        ;
    }

    //utensil type
    cout<<"\t\t5. UTENSIL TYPE"<<endl;
    cout<<"\t\ti. copper"<<endl;
    cout<<"\t\tii. steel"<<endl;
    cout<<"\t\tiii. silver"<<endl;
    cout<<"\t\tiv. any(0)"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>sel;
    switch(sel){
    case 1:
        //copper
        ;
    case 2:
        //steel
        ;
    case 3:
        //silver
        ;
    case 4:
        //any
        ;
    }
}

void utesil_detail(){
    cout<<"\t\t\tUTESNIL DETAILS"<<endl;
    cout<<"\t\t1. add utensil"<<endl;
    cout<<"\t\t2. list all utensil"<<endl;
    cout<<"\t\t3. Exit"<<endl;
    cout<<"\t\tUSMS@non~ # ";
    cin>>sel;
}

void admin :: utensil_add(){
    cout<<"\t\t\tADD NEW UTENSIL DETAILS"<<endl;
    cout<<"\t\t1. Utenisl ID"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>ut_data.ut_id;
    cout<<"\t\t2. Utensil name"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>ut_data.ut_name;
    cout<<"\t\t3. Utensil type"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>ut_data.ut_type;
    cout<<"\t\t4. Utensil exchange avaiblity"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>ut_data.ut_exch;
    cout<<"\t\t5. Utensil care"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>ut_data.ut_care;
    cout<<"\t\t6. Discount"<<endl;
    cout<<"\t\tUSMS@user~ # ";
    cin>>ut_data.ut_dis;
    cout<<endl;
    cout<<"\t\tNew Utesil is Successfully Added!!!"<<endl;
    cin.ignore();
    cout <<"\t\tPress Enter to Continue";
    cin.get();
}

void admin :: add_utensil_add(){
    admin obj;
    fstream file;
    file.open("utensil_detail.txt", ios::in | ios::out | ios::app);
    obj.utensil_add();
    file.write((char *)&obj, sizeof(obj));
    file.close();
}


int main()
{
    //intro();
    //wel_page();
    //system("cls");
    //intro();
    //user_login();
    //system("cls");
    //intro();
    //user_signup();
    //system("cls");
    //intro();
    //user_final_login();
    //utensil_type();
    //utensil_list();
    //utensil_filter();
    //utensil_final_list();
    //utensil_data();
    //bill();
    //cong();
    //admin_login();
    //system("cls");
    //intro();
    //admin_page();
    //system("cls");
    //intro();
    //user_detail();
    //system("cls");
    //intro();
    //utesil_detail();
    //system("cls");
    //intro();
    //utensil_add();
    //taking user signup fie system
    custormer m;
    //m.add_user_signup();
    //taking utensil file system
    //admin m;
    //m.add_utensil_add();
    m.search_name();


    return 0;
}






















































